﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

public class DemoController : Controller
{
    public IActionResult Index()
    {
        ViewData["Message"] = "Додаток з Razor!";
        return View();
    }

    public IActionResult List()
    {
        var countries = new List<string> { "Україна", "Польща", "Німеччина", "Франція" };
        return View(countries);
    }
}
